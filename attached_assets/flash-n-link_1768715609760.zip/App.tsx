
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, useCallback, Suspense, lazy } from 'react';
import IntroAnimation from './components/IntroAnimation';
import KeyboardShortcutsModal from './components/KeyboardShortcutsModal';
import { AppHeader } from './components/AppHeader';
import { NavigationTabs } from './components/NavigationTabs';
import { ViewMode } from './types';
import { Loader2 } from 'lucide-react';
import { ProjectProvider } from './contexts/ProjectContext';
import { ThemeProvider } from './contexts/ThemeContext';

// Lazy load heavy feature components for PWA performance optimization
const RepoAnalyzer = lazy(() => import('./components/RepoAnalyzer'));
const ArticleToInfographic = lazy(() => import('./components/ArticleToInfographic'));
const ImageEditor = lazy(() => import('./components/ImageEditor'));
const Home = lazy(() => import('./components/Home'));
const DevStudio = lazy(() => import('./components/DevStudio'));

const AppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewMode>(ViewMode.HOME);
  const [showIntro, setShowIntro] = useState(true);
  const [showShortcuts, setShowShortcuts] = useState(false);

  const handleNavigate = useCallback((mode: ViewMode) => {
    setCurrentView(mode);
  }, []);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Navigation: Alt + 1-5
      if (e.altKey && !e.shiftKey && !e.ctrlKey && !e.metaKey) {
        switch (e.key) {
          case '1': handleNavigate(ViewMode.HOME); break;
          case '2': handleNavigate(ViewMode.REPO_ANALYZER); break;
          case '3': handleNavigate(ViewMode.ARTICLE_INFOGRAPHIC); break;
          case '4': handleNavigate(ViewMode.IMAGE_EDITOR); break;
          case '5': handleNavigate(ViewMode.DEV_STUDIO); break;
        }
      }

      // Help: Shift + ?
      if (e.shiftKey && e.key === '?') {
        setShowShortcuts(prev => !prev);
      }

      // Close Modals: Escape
      if (e.key === 'Escape') {
        setShowShortcuts(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNavigate]);

  const handleIntroComplete = () => {
    setShowIntro(false);
  };

  // Suspense Fallback
  const PageLoader = () => (
    <div className="h-[60vh] flex items-center justify-center">
       <Loader2 className="w-8 h-8 text-slate-500 animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col transition-colors duration-500">
      {showIntro && <IntroAnimation onComplete={handleIntroComplete} />}
      
      {showShortcuts && <KeyboardShortcutsModal onClose={() => setShowShortcuts(false)} />}

      <AppHeader 
        hasApiKey={true} 
        onNavigateHome={() => setCurrentView(ViewMode.HOME)} 
        onShowShortcuts={() => setShowShortcuts(true)} 
      />

      <main className="flex-1 w-full max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col">
        <NavigationTabs currentView={currentView} onNavigate={handleNavigate} />

        <div className="flex-1">
            <Suspense fallback={<PageLoader />}>
                {currentView === ViewMode.HOME && (
                    <Home onNavigate={handleNavigate} />
                )}
                {currentView === ViewMode.REPO_ANALYZER && (
                    <div className="animate-in fade-in-30 slide-in-from-bottom-4 duration-500 ease-out">
                        <RepoAnalyzer 
                            onNavigate={handleNavigate} 
                        />
                    </div>
                )}
                {currentView === ViewMode.ARTICLE_INFOGRAPHIC && (
                    <div className="animate-in fade-in-30 slide-in-from-bottom-4 duration-500 ease-out">
                        <ArticleToInfographic />
                    </div>
                )}
                {currentView === ViewMode.IMAGE_EDITOR && (
                    <div className="animate-in fade-in-30 slide-in-from-bottom-4 duration-500 ease-out">
                        <ImageEditor 
                            onNavigate={handleNavigate}
                        />
                    </div>
                )}
                {currentView === ViewMode.DEV_STUDIO && (
                    <div className="animate-in fade-in-30 slide-in-from-bottom-4 duration-500 ease-out">
                        <DevStudio onNavigate={handleNavigate} />
                    </div>
                )}
            </Suspense>
        </div>
      </main>

      <footer className="py-6 mt-auto border-t border-white/5 transition-colors">
        <div className="max-w-7xl mx-auto text-center px-4">
          <p className="text-xs font-mono text-slate-600">
            <span className="text-violet-500/70">flash</span>:<span className="text-emerald-500/70">link</span>$ Powered by Nano Banana Pro | Press <kbd className="px-1.5 py-0.5 bg-white/5 border border-white/10 rounded-md text-slate-400">Shift + ?</kbd> for shortcuts
          </p>
        </div>
      </footer>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <ProjectProvider>
        <AppContent />
      </ProjectProvider>
    </ThemeProvider>
  );
};

export default App;

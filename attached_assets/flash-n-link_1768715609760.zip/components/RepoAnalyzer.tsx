
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState } from 'react';
import { fetchRepoFileTree } from '../services/githubService';
import { generateInfographic, vectorizeInfographic, suggestProjectTasks } from '../services/geminiService';
import { RepoFileTree, ViewMode, RepoHistoryItem } from '../types';
import { AlertCircle, Loader2, Layers, Box, Sparkles, Command, Palette, Globe, KeyRound, ListTodo, Terminal } from 'lucide-react';
import { LoadingState } from './LoadingState';
import ImageViewer from './ImageViewer';
import { HistoryGrid } from './HistoryGrid';
import { InfographicResultCard } from './InfographicResultCard';
import { LANGUAGES, FLOW_STYLES } from '../constants';
import { useProjectContext } from '../contexts/ProjectContext';
import { jsPDF } from 'jspdf';

interface RepoAnalyzerProps {
  onNavigate: (mode: ViewMode, data?: any) => void;
}

const RepoAnalyzer: React.FC<RepoAnalyzerProps> = ({ onNavigate }) => {
  const { 
    repoHistory, 
    addRepoHistory, 
    setCurrentProject,
    addTask 
  } = useProjectContext();

  const [repoInput, setRepoInput] = useState('');
  const [selectedStyle, setSelectedStyle] = useState(FLOW_STYLES[0]);
  const [selectedLanguage, setSelectedLanguage] = useState(LANGUAGES[0].value);
  const [customStyle, setCustomStyle] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loadingStage, setLoadingStage] = useState<string>('');
  const [isVectorizing, setIsVectorizing] = useState(false);
  const [isGeneratingTasks, setIsGeneratingTasks] = useState(false);
  const [tasksGenerated, setTasksGenerated] = useState(false);
  
  // Infographic State
  const [infographicData, setInfographicData] = useState<string | null>(null);
  const [infographic3DData, setInfographic3DData] = useState<string | null>(null);
  const [generating3D, setGenerating3D] = useState(false);
  const [currentFileTree, setCurrentFileTree] = useState<RepoFileTree[] | null>(null);
  const [currentRepoName, setCurrentRepoName] = useState<string>('');
  
  // Viewer State
  const [fullScreenImage, setFullScreenImage] = useState<{src: string, alt: string} | null>(null);

  const parseRepoInput = (input: string): { owner: string, repo: string } | null => {
    const cleanInput = input.trim().replace(/\/$/, '');
    try {
      const url = new URL(cleanInput);
      if (url.hostname === 'github.com') {
        const parts = url.pathname.split('/').filter(Boolean);
        if (parts.length >= 2) return { owner: parts[0], repo: parts[1] };
      }
    } catch (e) { }
    const parts = cleanInput.split('/');
    if (parts.length === 2 && parts[0] && parts[1]) return { owner: parts[0], repo: parts[1] };
    return null;
  };

  const addToHistory = (repoName: string, imageData: string, is3D: boolean, style: string) => {
     const newItem: RepoHistoryItem = {
         id: Date.now().toString(),
         repoName,
         imageData,
         is3D,
         style,
         date: new Date()
     };
     addRepoHistory(newItem);
  };

  const handleApiError = (err: any) => {
      // Check for both the raw API error message and our enhanced service error message
      const msg = err.message || '';
      if (msg.includes("Requested entity was not found") || msg.includes("Model Not Found") || msg.includes("Access Denied")) {
          const confirmSwitch = window.confirm(
              "BILLING REQUIRED: The current API key does not have access to these models.\n\n" +
              "This feature requires a paid Google Cloud Project. Please switch to a valid paid API Key."
          );
          if (confirmSwitch) {
              window.location.reload();
          }
      }
      setError(msg || 'An unexpected error occurred during analysis.');
  }

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfographicData(null);
    setInfographic3DData(null);
    setCurrentFileTree(null);
    setTasksGenerated(false);

    const repoDetails = parseRepoInput(repoInput);
    if (!repoDetails) {
      setError('Invalid format. Use "owner/repo" or a full GitHub URL (https://github.com/...).');
      return;
    }

    setLoading(true);
    setCurrentRepoName(repoDetails.repo);
    try {
      setLoadingStage('CONNECTING TO GITHUB');
      const fileTree = await fetchRepoFileTree(repoDetails.owner, repoDetails.repo);

      if (fileTree.length === 0) throw new Error('No relevant code files found in this repository.');
      setCurrentFileTree(fileTree);

      // Simple graph generation for DevStudio context
      // In a real app, this would be a full dependency analysis. 
      // Here we mock it based on file tree for the visualizer context.
      const nodes = fileTree.slice(0, 30).map((f, i) => ({ id: f.path, group: i % 5, label: f.path.split('/').pop() || f.path }));
      const links = nodes.slice(1).map((n, i) => ({ source: nodes[0].id, target: n.id, value: 1 }));
      
      setCurrentProject({
          repoName: `${repoDetails.owner}/${repoDetails.repo}`, // Store full name for fetchFileContent
          fileTree: fileTree,
          graphData: { nodes, links }
      });

      setLoadingStage('ANALYZING STRUCTURE & GENERATING');
      
      const styleToUse = selectedStyle === 'Custom' ? customStyle : selectedStyle;

      const infographicBase64 = await generateInfographic(repoDetails.repo, fileTree, styleToUse, false, selectedLanguage);
      
      if (infographicBase64) {
        setInfographicData(infographicBase64);
        addToHistory(repoDetails.repo, infographicBase64, false, styleToUse);
      } else {
          throw new Error("Failed to generate visual.");
      }

    } catch (err: any) {
      handleApiError(err);
    } finally {
      setLoading(false);
      setLoadingStage('');
    }
  };

  const handleGenerate3D = async () => {
    if (!currentFileTree || !currentRepoName) return;
    setGenerating3D(true);
    try {
      const styleToUse = selectedStyle === 'Custom' ? customStyle : selectedStyle;
      const data = await generateInfographic(currentRepoName, currentFileTree, styleToUse, true, selectedLanguage);
      if (data) {
          setInfographic3DData(data);
          addToHistory(currentRepoName, data, true, styleToUse);
      }
    } catch (err: any) {
      handleApiError(err);
    } finally {
      setGenerating3D(false);
    }
  };

  const handleGenerateTasks = async () => {
      if (!currentFileTree || !currentRepoName) return;
      setIsGeneratingTasks(true);
      try {
          const tasks = await suggestProjectTasks(currentRepoName, currentFileTree);
          tasks.forEach(t => addTask(t));
          setTasksGenerated(true);
      } catch (e) {
          console.error(e);
          alert("Failed to generate tasks.");
      } finally {
          setIsGeneratingTasks(false);
      }
  };

  const handleExportSvg = async (base64: string, nameSuffix: string) => {
    if (isVectorizing) return;
    setIsVectorizing(true);
    try {
      const svgCode = await vectorizeInfographic(base64, `${currentRepoName} ${nameSuffix} diagram`);
      if (svgCode) {
        const blob = new Blob([svgCode], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${currentRepoName}-infographic-${nameSuffix}.svg`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        alert("Failed to synthesize SVG code.");
      }
    } catch (err) {
      console.error(err);
      alert("SVG Synthesis failed. Ensure you have a valid paid API key.");
    } finally {
      setIsVectorizing(false);
    }
  };

  const handleExportPdf = (base64: string, nameSuffix: string) => {
      if (!base64) return;
      try {
          const doc = new jsPDF({
              orientation: 'landscape',
              unit: 'px',
              format: [1920, 1080]
          });
          doc.addImage(`data:image/png;base64,${base64}`, 'PNG', 0, 0, 1920, 1080);
          doc.save(`${currentRepoName}-${nameSuffix}.pdf`);
      } catch (e) {
          console.error("PDF Export failed", e);
          alert("Failed to generate PDF.");
      }
  };

  const loadFromHistory = (item: RepoHistoryItem) => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setCurrentRepoName(item.repoName);
      if (item.is3D) {
          setInfographic3DData(item.imageData);
      } else {
          setInfographicData(item.imageData);
          setInfographic3DData(null);
      }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 mb-20">
      
      {fullScreenImage && (
          <ImageViewer 
            src={fullScreenImage.src} 
            alt={fullScreenImage.alt} 
            onClose={() => setFullScreenImage(null)} 
          />
      )}

      {/* Hero Section */}
      <div className="text-center max-w-3xl mx-auto space-y-6">
        <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-200 to-slate-500 font-sans leading-tight">
          Codebase <span className="text-violet-400">Intelligence</span>.
        </h2>
        <p className="text-slate-400 text-lg md:text-xl font-light tracking-wide">
          Turn any repository into a fully analyzed, interactive architectural blueprint.
        </p>
      </div>

      {/* Input Section */}
      <div className="max-w-xl mx-auto relative z-10">
        <form onSubmit={handleAnalyze} className="glass-panel rounded-2xl p-2 transition-all focus-within:ring-1 focus-within:ring-violet-500/50 focus-within:border-violet-500/50">
          <div className="flex items-center">
             <div className="pl-3 text-slate-500">
                <Command className="w-5 h-5" />
             </div>
             <input
                type="text"
                value={repoInput}
                onChange={(e) => setRepoInput(e.target.value)}
                placeholder="owner/repo or https://github.com/..."
                aria-label="GitHub Repository Name or URL"
                className="w-full bg-transparent border-none text-white placeholder:text-slate-600 focus:ring-0 text-lg px-4 py-2 font-mono"
              />
              <div className="pr-2">
                <button
                type="submit"
                disabled={loading || !repoInput.trim()}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 border border-white/10 font-mono text-sm"
                title="Press Enter to analyze"
                >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "RUN_ANALYSIS"}
                </button>
             </div>
          </div>

          {/* Controls: Style and Language */}
          <div className="mt-2 pt-2 border-t border-white/5 px-3 pb-1 space-y-3">
             <div className="flex items-center gap-3 overflow-x-auto no-scrollbar">
                 <div className="flex items-center gap-1.5 text-slate-500 font-mono text-[10px] uppercase tracking-wider shrink-0">
                     <Palette className="w-3 h-3" /> Style:
                 </div>
                 <div className="flex gap-2">
                     {FLOW_STYLES.map(style => (
                         <button
                            key={style}
                            type="button"
                            onClick={() => setSelectedStyle(style)}
                            className={`text-[11px] px-2.5 py-1 rounded-md font-mono transition-all whitespace-nowrap ${
                                selectedStyle === style 
                                ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' 
                                : 'bg-white/5 text-slate-500 hover:text-slate-300 border border-transparent hover:border-white/10'
                            }`}
                         >
                             {style}
                         </button>
                     ))}
                 </div>
             </div>
             
             <div className="flex flex-wrap gap-3">
               <div className="flex items-center gap-2 bg-slate-950/50 border border-white/10 rounded-lg px-2 py-1 shrink-0 min-w-0 max-w-full">
                  <Globe className="w-3 h-3 text-slate-500 shrink-0" />
                  <select
                    value={selectedLanguage}
                    onChange={(e) => setSelectedLanguage(e.target.value)}
                    aria-label="Select Language"
                    className="bg-transparent border-none text-xs text-slate-300 focus:ring-0 p-0 font-mono cursor-pointer min-w-0 flex-1 truncate"
                  >
                    {LANGUAGES.map((lang) => (
                      <option key={lang.value} value={lang.value} className="bg-slate-900 text-slate-300">
                        {lang.label}
                      </option>
                    ))}
                  </select>
               </div>

               {selectedStyle === 'Custom' && (
                   <input 
                      type="text" 
                      value={customStyle}
                      onChange={(e) => setCustomStyle(e.target.value)}
                      placeholder="Custom style..."
                      aria-label="Custom Style"
                      className="flex-1 min-w-[120px] bg-slate-950/50 border border-white/10 rounded-lg px-3 py-1 text-xs text-slate-200 placeholder:text-slate-600 focus:ring-1 focus:ring-violet-500/50 focus:border-violet-500/50 font-mono transition-all"
                   />
               )}
             </div>
          </div>
        </form>
      </div>

      {error && (
        <div className="max-w-2xl mx-auto p-4 glass-panel border-red-500/30 rounded-xl flex items-center gap-3 text-red-400 animate-in fade-in slide-in-from-top-2 font-mono text-sm">
          <AlertCircle className="w-5 h-5 flex-shrink-0 text-red-500" />
          <p className="flex-1">{error}</p>
          {error.includes("Required") && (
              <button 
                onClick={() => window.location.reload()}
                className="px-3 py-1 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded text-xs font-bold transition-colors flex items-center gap-1"
              >
                 <KeyRound className="w-3 h-3" /> SWITCH KEY
              </button>
          )}
        </div>
      )}

      {loading && (
        <LoadingState message={loadingStage} type="repo" />
      )}

      {/* Post-Analysis Actions Bar */}
      {infographicData && !loading && (
          <div className="flex flex-wrap justify-center gap-4 animate-in fade-in slide-in-from-bottom-2">
              <button
                onClick={handleGenerateTasks}
                disabled={isGeneratingTasks || tasksGenerated}
                className="px-4 py-2 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30 rounded-xl flex items-center gap-2 font-mono text-sm transition-all disabled:opacity-50"
              >
                  {isGeneratingTasks ? <Loader2 className="w-4 h-4 animate-spin" /> : <ListTodo className="w-4 h-4" />}
                  {tasksGenerated ? "TASKS_GENERATED" : "AUTO_GENERATE_TASKS"}
              </button>

              <button
                onClick={() => onNavigate(ViewMode.DEV_STUDIO)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl flex items-center gap-2 font-mono text-sm transition-all"
              >
                  <Terminal className="w-4 h-4" /> OPEN_DEV_STUDIO
              </button>
          </div>
      )}

      {/* Results Section */}
      {infographicData && !loading && (
        <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* 2D Infographic Card */}
              <InfographicResultCard
                title={`${currentRepoName.split('/').pop()}-infographic-2d`}
                label="Flow_Diagram"
                icon={Layers}
                iconColorClass="text-violet-400"
                imageData={infographicData}
                isVectorizing={isVectorizing}
                onFullScreen={() => setFullScreenImage({src: `data:image/png;base64,${infographicData}`, alt: `${currentRepoName} 2D`})}
                onExportSvg={() => handleExportSvg(infographicData!, '2d')}
                onExportPdf={() => handleExportPdf(infographicData!, '2d')}
              />

              {/* 3D Infographic Card */}
              <InfographicResultCard
                title={`${currentRepoName.split('/').pop()}-infographic-3d`}
                label="Holographic_Model"
                icon={Box}
                iconColorClass="text-fuchsia-400"
                imageData={infographic3DData}
                isVectorizing={isVectorizing}
                is3D={true}
                isGenerating={generating3D}
                onFullScreen={() => infographic3DData && setFullScreenImage({src: `data:image/png;base64,${infographic3DData}`, alt: `${currentRepoName} 3D`})}
                onExportSvg={() => infographic3DData && handleExportSvg(infographic3DData, '3d')}
                onExportPdf={() => infographic3DData && handleExportPdf(infographic3DData, '3d')}
                onGenerateAction={handleGenerate3D}
                generateActionLabel="GENERATE_MODEL"
                generateActionIcon={Sparkles}
                emptyStateMessage="Render tabletop perspective?"
              />
          </div>
        </div>
      )}

      {/* History Section using reusable grid */}
      <HistoryGrid items={repoHistory} onSelect={loadFromHistory} type="repo" />
    </div>
  );
};

export default RepoAnalyzer;


/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useMemo } from 'react';
import D3FlowChart from './D3FlowChart';
import { D3Node, ViewMode, D3Link } from '../types';
import { askNodeSpecificQuestion } from '../services/geminiService';
import { fetchFileContent, searchRepoCode, SearchResult } from '../services/githubService';
import { Terminal, GitBranch, Cpu, MessageSquare, Zap, Code2, ArrowLeft, Sparkles, Bug, Search, ListTodo, FileCode, Loader2, UserCog, GraduationCap, ShieldAlert, LineChart, Filter, Info, X, Folder, FileType, ChevronRight, ChevronDown, Check, FileSearch, Bot, Layers, CheckSquare, Square, Play, Moon, Sun, Sunset } from 'lucide-react';
import { TaskList } from './TaskList';
import { useProjectContext } from '../contexts/ProjectContext';
import { useTheme, Theme } from '../contexts/ThemeContext';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

interface DevStudioProps {
  onNavigate: (mode: ViewMode) => void;
}

const QUICK_ACTIONS = [
  { label: "Explain", icon: Search, prompt: "Explain the purpose and likely functionality of this component based on its name and connections." },
  { label: "Optimize", icon: Zap, prompt: "Suggest performance optimizations or refactoring for this specific component." },
  { label: "Debug", icon: Bug, prompt: "What are potential failure points, security risks, or bugs common in components like this one?" },
];

const PERSONAS = [
    { id: "Senior Architect", label: "Architect", icon: UserCog, desc: "Focuses on patterns, scalability, and clean code." },
    { id: "Security Engineer", label: "SecOps", icon: ShieldAlert, desc: "Paranoid about vulnerabilities and exploits." },
    { id: "Product Manager", label: "Product", icon: LineChart, desc: "Focuses on user value and business logic." },
    { id: "Junior Mentor", label: "Mentor", icon: GraduationCap, desc: "Explains simply (ELI5) for learning." },
];

const CLUSTER_THRESHOLD = 5;

/**
 * DevStudio Component
 * 
 * Provides a comprehensive development environment analysis interface.
 * Key Features:
 * - D3.js interactive dependency graph with directory clustering.
 * - Dynamic filtering by file type and directory.
 * - Deep search across file names and content.
 * - AI Assistant with persona switching for context-aware coding help.
 * - Integrated Task Management.
 * - User-selectable visual themes.
 */
const DevStudio: React.FC<DevStudioProps> = ({ onNavigate }) => {
  const { currentProject } = useProjectContext();
  const { theme, setTheme } = useTheme();
  
  // Selection State
  const [selectedNode, setSelectedNode] = useState<D3Node | null>(null);
  
  // Chat & AI State
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [questionInput, setQuestionInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'tasks' | 'code'>('chat');
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [loadingContent, setLoadingContent] = useState(false);
  const [activePersona, setActivePersona] = useState(PERSONAS[0]);
  const [isPersonaMenuOpen, setIsPersonaMenuOpen] = useState(false);
  
  // Filtering State
  // Applied filters affect the graph
  const [appliedExtensions, setAppliedExtensions] = useState<string[]>([]);
  const [appliedDirectories, setAppliedDirectories] = useState<string[]>([]);
  
  // Temp filters for the UI menu before applying
  const [tempExtensions, setTempExtensions] = useState<string[]>([]);
  const [tempDirectories, setTempDirectories] = useState<string[]>([]);
  
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [filterTab, setFilterTab] = useState<'types' | 'dirs'>('types');

  // Clustering State
  // Tracks which directories are expanded (files shown) vs collapsed (cluster node shown)
  const [expandedClusters, setExpandedClusters] = useState<Set<string>>(new Set());

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [localSearchResults, setLocalSearchResults] = useState<D3Node[]>([]);
  const [contentSearchResults, setContentSearchResults] = useState<SearchResult[]>([]);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isSearchingContent, setIsSearchingContent] = useState(false);
  const [highlightedNodeIds, setHighlightedNodeIds] = useState<string[]>([]);

  const [showFileModal, setShowFileModal] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (activeTab === 'chat') {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory, chatLoading, activeTab]);

  // Sync temp state when opening filter menu
  const toggleFilterMenu = () => {
      if (!isFilterOpen) {
          setTempExtensions(appliedExtensions);
          setTempDirectories(appliedDirectories);
      }
      setIsFilterOpen(!isFilterOpen);
  };

  const applyFilters = () => {
      setAppliedExtensions(tempExtensions);
      setAppliedDirectories(tempDirectories);
      setIsFilterOpen(false);
  };

  /**
   * Memoized: Compute dynamic stats for filters based on CURRENT TEMP SELECTION in the menu.
   * This ensures the counts for Directories update when Extensions are filtered, and vice versa.
   */
  const stats = useMemo(() => {
      if (!currentProject) return { extCounts: {}, dirCounts: {}, allExts: [], allDirs: [] };
      
      const extCounts: Record<string, number> = {};
      const dirCounts: Record<string, number> = {};
      const allExtsSet = new Set<string>();
      const allDirsSet = new Set<string>();

      // First pass: Collect all possible values from the full dataset
      currentProject.graphData.nodes.forEach(node => {
          const parts = node.id.split('.');
          const ext = parts.length > 1 ? '.' + parts[parts.length - 1] : 'No Ext';
          allExtsSet.add(ext);

          const pathParts = node.id.split('/');
          const dir = pathParts.length > 1 ? pathParts[0] : '(Root)';
          allDirsSet.add(dir);
      });

      // Second pass: Calculate dynamic counts based on TEMP filters (for UI feedback)
      
      // 1. Extension Counts (filtered by Directories)
      currentProject.graphData.nodes.forEach(node => {
          const pathParts = node.id.split('/');
          const dir = pathParts.length > 1 ? pathParts[0] : '(Root)';
          // Use tempDirectories here for live feedback in the menu
          const dirMatch = tempDirectories.length === 0 || tempDirectories.includes(dir);
          
          if (dirMatch) {
              const parts = node.id.split('.');
              const ext = parts.length > 1 ? '.' + parts[parts.length - 1] : 'No Ext';
              extCounts[ext] = (extCounts[ext] || 0) + 1;
          }
      });

      // 2. Directory Counts (filtered by Extensions)
      currentProject.graphData.nodes.forEach(node => {
          const parts = node.id.split('.');
          const ext = parts.length > 1 ? '.' + parts[parts.length - 1] : 'No Ext';
          // Use tempExtensions here for live feedback in the menu
          const extMatch = tempExtensions.length === 0 || tempExtensions.includes(ext);
          
          if (extMatch) {
              const pathParts = node.id.split('/');
              const dir = pathParts.length > 1 ? pathParts[0] : '(Root)';
              dirCounts[dir] = (dirCounts[dir] || 0) + 1;
          }
      });

      return {
          extCounts,
          dirCounts,
          allExts: Array.from(allExtsSet).sort(),
          allDirs: Array.from(allDirsSet).sort()
      };
  }, [currentProject, tempExtensions, tempDirectories]);

  /**
   * Memoized: Process Graph Data for Visualization.
   * Uses APPLIED filters.
   */
  const processedGraphData = useMemo(() => {
      if (!currentProject) return { nodes: [], links: [] };

      // 1. Filter original nodes
      const filteredNodes = currentProject.graphData.nodes.filter(node => {
          const parts = node.id.split('.');
          const ext = parts.length > 1 ? '.' + parts[parts.length - 1] : 'No Ext';
          const extMatch = appliedExtensions.length === 0 || appliedExtensions.includes(ext);

          const pathParts = node.id.split('/');
          const dir = pathParts.length > 1 ? pathParts[0] : '(Root)';
          const dirMatch = appliedDirectories.length === 0 || appliedDirectories.includes(dir);

          return extMatch && dirMatch;
      });

      const filteredNodeIds = new Set(filteredNodes.map(n => n.id));

      // 2. Group by Directory for Clustering
      const dirGroups: Record<string, D3Node[]> = {};
      filteredNodes.forEach(node => {
          const pathParts = node.id.split('/');
          const dir = pathParts.length > 1 ? pathParts[0] : '(Root)';
          if (!dirGroups[dir]) dirGroups[dir] = [];
          dirGroups[dir].push(node);
      });

      const finalNodes: D3Node[] = [];
      const nodeMapping = new Map<string, string>(); // Maps original ID -> Displayed ID (Node or Cluster)

      // 3. Create Cluster Nodes
      Object.entries(dirGroups).forEach(([dir, nodes]) => {
          if (nodes.length > CLUSTER_THRESHOLD && !expandedClusters.has(dir)) {
              // Create Cluster
              const clusterId = `cluster-${dir}`;
              finalNodes.push({
                  id: clusterId,
                  group: nodes[0].group, // Use group of first node
                  label: `${dir}/ (${nodes.length})`,
                  type: 'cluster',
                  fileCount: nodes.length,
                  childNodes: nodes
              });
              // Map all children to this cluster
              nodes.forEach(n => nodeMapping.set(n.id, clusterId));
          } else {
              // Keep original nodes
              nodes.forEach(n => {
                  finalNodes.push({ ...n, type: 'file' });
                  nodeMapping.set(n.id, n.id);
              });
          }
      });

      // 4. Re-route Links
      const finalLinks: D3Link[] = [];
      const linkDedup = new Set<string>();

      currentProject.graphData.links.forEach(link => {
          const sourceIdOriginal = typeof link.source === 'object' ? (link.source as any).id : link.source;
          const targetIdOriginal = typeof link.target === 'object' ? (link.target as any).id : link.target;

          // Only consider links where both ends exist in our filtered set
          if (filteredNodeIds.has(sourceIdOriginal) && filteredNodeIds.has(targetIdOriginal)) {
              const sourceId = nodeMapping.get(sourceIdOriginal);
              const targetId = nodeMapping.get(targetIdOriginal);

              if (sourceId && targetId && sourceId !== targetId) {
                  const linkKey = `${sourceId}-${targetId}`;
                  if (!linkDedup.has(linkKey)) {
                      finalLinks.push({
                          source: sourceId,
                          target: targetId,
                          value: link.value
                      });
                      linkDedup.add(linkKey);
                  }
              }
          }
      });

      return { nodes: finalNodes, links: finalLinks };

  }, [currentProject, appliedExtensions, appliedDirectories, expandedClusters]);

  const toggleTempFilter = (item: string, type: 'ext' | 'dir') => {
      if (type === 'ext') {
          setTempExtensions(prev => prev.includes(item) ? prev.filter(e => e !== item) : [...prev, item]);
      } else {
          setTempDirectories(prev => prev.includes(item) ? prev.filter(e => e !== item) : [...prev, item]);
      }
  };

  const clearTempFilters = () => {
      setTempExtensions([]);
      setTempDirectories([]);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const q = e.target.value;
      setSearchQuery(q);
      setContentSearchResults([]); // Clear content results on typing
      
      if (q.length > 0 && currentProject) {
          const lower = q.toLowerCase();
          const results = currentProject.graphData.nodes.filter(n => 
              n.label.toLowerCase().includes(lower) || n.id.toLowerCase().includes(lower)
          );
          setLocalSearchResults(results.slice(0, 5)); // Limit results
      } else {
          setLocalSearchResults([]);
      }
  };

  const executeContentSearch = async () => {
      if (!currentProject || !searchQuery.trim()) return;
      setIsSearchingContent(true);
      try {
          const parts = currentProject.repoName.split('/');
          if (parts.length === 2) {
              const results = await searchRepoCode(parts[0], parts[1], searchQuery);
              setContentSearchResults(results);
              
              // Automatically highlight found nodes
              const foundIds = results.map(r => r.path).filter(path => currentProject.graphData.nodes.some(n => n.id === path));
              setHighlightedNodeIds(foundIds);
              
              // Let's Auto-Expand relevant clusters.
              const clustersToExpand = new Set<string>();
              foundIds.forEach(id => {
                  const pathParts = id.split('/');
                  const dir = pathParts.length > 1 ? pathParts[0] : '(Root)';
                  clustersToExpand.add(dir);
              });
              
              setExpandedClusters(prev => {
                  const next = new Set(prev);
                  clustersToExpand.forEach(c => next.add(c));
                  return next;
              });

          }
      } catch (e) {
          console.error(e);
      } finally {
          setIsSearchingContent(false);
      }
  };

  const selectSearchResult = (node: D3Node) => {
      setHighlightedNodeIds([node.id]);
      
      // Auto expand cluster if needed
      const pathParts = node.id.split('/');
      const dir = pathParts.length > 1 ? pathParts[0] : '(Root)';
      setExpandedClusters(prev => new Set(prev).add(dir));
      
      setSearchQuery('');
      setLocalSearchResults([]);
      setContentSearchResults([]);
      setIsSearchFocused(false);
      
      // Select for chat context
      setSelectedNode(node);
  };

  const selectPathResult = (path: string) => {
      // Find if node exists in graph
      const node = currentProject?.graphData.nodes.find(n => n.id === path);
      if (node) {
          selectSearchResult(node);
      } else {
          // Handle off-graph nodes
          const mockNode: D3Node = { id: path, group: 0, label: path.split('/').pop() || path, type: 'file' };
          setSelectedNode(mockNode);
          setSearchQuery('');
          setLocalSearchResults([]);
          setContentSearchResults([]);
          setIsSearchFocused(false);
      }
  };

  const handleThemeChange = (newTheme: Theme) => {
      setTheme(newTheme);
  };

  if (!currentProject) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-slate-500 space-y-6 text-center p-8 animate-in fade-in">
        <div className="p-6 bg-slate-900/50 rounded-full border border-indigo-500/20 shadow-neon-violet">
             <GitBranch className="w-16 h-16 text-indigo-400 opacity-80" />
        </div>
        <div className="space-y-2">
            <h3 className="text-2xl font-bold text-slate-200 font-sans">Dev Studio Offline</h3>
            <p className="font-mono text-sm max-w-md mx-auto">No repository data is currently loaded. Please run an analysis first.</p>
        </div>
        <button 
            onClick={() => onNavigate(ViewMode.REPO_ANALYZER)}
            className="px-6 py-3 bg-indigo-500 text-white rounded-xl font-bold hover:bg-indigo-400 transition-all flex items-center gap-2 shadow-lg shadow-indigo-500/20"
        >
            <ArrowLeft className="w-4 h-4" /> Return to Analyzer
        </button>
      </div>
    );
  }

  const handleNodeClick = async (node: D3Node) => {
    // Check if Cluster
    if (node.type === 'cluster') {
        // Expand Cluster
        const dirName = node.id.replace('cluster-', '');
        setExpandedClusters(prev => {
            const next = new Set(prev);
            if (next.has(dirName)) next.delete(dirName);
            else next.add(dirName);
            return next;
        });
        return;
    }

    // Normal File Click
    setSelectedNode(node);
    setHighlightedNodeIds([node.id]);
    setShowFileModal(true);
    
    // Attempt to fetch content
    if (node.id.match(/\.(js|ts|jsx|tsx|css|html|json|py|rs|go|java|c|cpp|md|yml|yaml)$/i)) {
       setLoadingContent(true);
       setFileContent(null);
       const parts = currentProject.repoName.split('/');
       if (parts.length === 2) {
           const content = await fetchFileContent(parts[0], parts[1], node.id);
           setFileContent(content);
           if (content) setActiveTab('code'); 
       }
       setLoadingContent(false);
    } else {
        setFileContent(null);
    }
  };

  const executePrompt = async (promptText: string, nodeOverride?: D3Node | null) => {
    if (!currentProject.fileTree) return;
    const node = nodeOverride !== undefined ? nodeOverride : selectedNode;
    const targetNodeLabel = node ? node.label : "the overall architecture";

    setChatHistory(prev => [...prev, { role: 'user', text: promptText }]);
    setChatLoading(true);

    try {
        const answer = await askNodeSpecificQuestion(
            targetNodeLabel, 
            promptText, 
            currentProject.fileTree,
            fileContent || undefined,
            activePersona.id
        );
        setChatHistory(prev => [...prev, { role: 'model', text: answer }]);
    } catch (error) {
        setChatHistory(prev => [...prev, { role: 'model', text: "Error processing your request." }]);
    } finally {
        setChatLoading(false);
    }
  }

  const handleAskQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionInput.trim()) return;
    const q = questionInput;
    setQuestionInput('');
    await executePrompt(q);
  };

  const handleQuickAction = (promptTemplate: string) => {
      if (selectedNode) {
         executePrompt(promptTemplate);
         setActiveTab('chat');
      }
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-auto lg:h-[calc(100vh-180px)] min-h-0 lg:min-h-[600px] relative">
      
      {/* File Details Modal */}
      {showFileModal && selectedNode && (
          <div className="fixed inset-0 z-[50] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4" onClick={() => setShowFileModal(false)}>
              <div className="w-full max-w-4xl h-[80vh] glass-panel rounded-3xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200 border border-white/10 shadow-2xl" onClick={e => e.stopPropagation()}>
                  <div className="px-6 py-4 bg-slate-900/50 border-b border-white/10 flex items-center justify-between shrink-0">
                      <div className="flex items-center gap-4">
                          <div className="p-2 bg-indigo-500/10 rounded-xl border border-indigo-500/20">
                             <FileCode className="w-6 h-6 text-indigo-400" />
                          </div>
                          <div>
                             <h2 className="text-white font-bold font-mono text-base">{selectedNode.label}</h2>
                             <p className="text-xs text-slate-500 font-mono mt-0.5">{selectedNode.id}</p>
                          </div>
                      </div>
                      <button onClick={() => setShowFileModal(false)} className="p-2 hover:bg-white/10 rounded-xl transition-colors text-slate-400 hover:text-white">
                          <X className="w-6 h-6" />
                      </button>
                  </div>
                  
                  <div className="flex-1 overflow-auto bg-[#0d1117] relative flex flex-col">
                      {loadingContent ? (
                          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                              <Loader2 className="w-10 h-10 text-indigo-500 animate-spin" />
                              <p className="text-slate-500 font-mono text-xs animate-pulse">FETCHING_BLOB...</p>
                          </div>
                      ) : fileContent ? (
                          <div className="flex-1 relative">
                              <div className="absolute top-0 left-0 w-8 h-full bg-slate-900/50 border-r border-white/5 flex flex-col items-end pt-4 pr-2 select-none">
                                  {fileContent.split('\n').map((_, i) => (
                                      <span key={i} className="text-[10px] text-slate-700 font-mono leading-relaxed">{i + 1}</span>
                                  ))}
                              </div>
                              <pre className="pl-12 pr-6 py-4 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap selection:bg-indigo-500/30">
                                  {fileContent}
                              </pre>
                          </div>
                      ) : (
                          <div className="flex flex-col items-center justify-center h-full text-slate-600 space-y-4 opacity-60">
                              <div className="p-4 bg-white/5 rounded-full">
                                <Info className="w-10 h-10" />
                              </div>
                              <div className="text-center space-y-1">
                                <p className="text-sm font-mono font-medium">Binary or Large File</p>
                                <p className="text-xs font-mono text-slate-500">Preview not available for this node type.</p>
                              </div>
                          </div>
                      )}
                  </div>
                  
                  {/* Modal Footer Actions */}
                  <div className="px-6 py-3 bg-slate-900/80 border-t border-white/10 flex justify-end gap-3 shrink-0">
                      <button 
                        onClick={() => { setShowFileModal(false); setActiveTab('chat'); }}
                        className="px-4 py-2 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded-lg text-xs font-mono transition-colors border border-indigo-500/20"
                      >
                          Ask Assistant
                      </button>
                      <button 
                        onClick={() => setShowFileModal(false)}
                        className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg text-xs font-mono transition-colors"
                      >
                          Close
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Left Pane: Interactive Graph */}
      <div className="w-full h-[400px] lg:h-auto lg:flex-1 flex flex-col glass-panel rounded-3xl overflow-hidden relative group/graph transition-colors">
         <div className="px-4 py-3 bg-slate-950/50 border-b border-white/5 flex items-center justify-between shrink-0 z-20 relative">
            <div className="flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-300 font-mono uppercase tracking-wider hidden md:block">Live_Dependency_Graph</h3>
            </div>

            {/* File Search Bar */}
            <div className="flex-1 max-w-sm mx-4 relative">
                 <div className="relative group">
                     <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                     <input 
                        type="text"
                        value={searchQuery}
                        onChange={handleSearchChange}
                        onFocus={() => setIsSearchFocused(true)}
                        onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                        placeholder="Search files or content..."
                        className="w-full bg-slate-900/20 border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-300 placeholder:text-slate-600 focus:ring-1 focus:ring-indigo-500/50 focus:border-indigo-500/50 font-mono transition-all"
                     />
                 </div>
                 
                 {/* Search Results Dropdown */}
                 {isSearchFocused && searchQuery && (
                     <div className="absolute top-full left-0 w-full mt-2 bg-slate-900 border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-100 max-h-80 overflow-y-auto">
                         
                         {localSearchResults.length > 0 && (
                             <>
                                <div className="px-3 py-1.5 bg-white/5 text-[10px] text-slate-500 font-mono uppercase tracking-wider">Matching Nodes</div>
                                {localSearchResults.map((node) => (
                                     <div 
                                        key={node.id} 
                                        className="w-full text-left px-3 py-2 hover:bg-white/5 border-b border-white/5 last:border-0 transition-colors group flex items-center justify-between cursor-pointer"
                                        onClick={() => selectSearchResult(node)}
                                     >
                                        <div className="flex items-center gap-2 flex-1 min-w-0">
                                            <FileCode className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                                            <span className="text-xs font-mono text-slate-300 truncate">{node.label}</span>
                                        </div>
                                     </div>
                                 ))}
                             </>
                         )}

                         <div className="px-3 py-1.5 bg-white/5 text-[10px] text-slate-500 font-mono uppercase tracking-wider border-t border-white/5">
                             File Content Search
                         </div>
                         
                         {isSearchingContent ? (
                            <div className="p-4 flex items-center justify-center gap-2 text-slate-500">
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span className="text-xs font-mono">Searching repo...</span>
                            </div>
                         ) : contentSearchResults.length > 0 ? (
                            contentSearchResults.map((result, idx) => (
                                <div 
                                   key={idx} 
                                   className="w-full text-left px-3 py-2 hover:bg-white/5 border-b border-white/5 last:border-0 transition-colors group flex flex-col cursor-pointer"
                                   onClick={() => selectPathResult(result.path)}
                                >
                                   <div className="flex items-center gap-2 min-w-0 mb-1">
                                       <FileSearch className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                                       <span className="text-xs font-mono text-slate-300 truncate">{result.path}</span>
                                   </div>
                                   {result.fragment && (
                                       <div className="pl-5 text-[10px] text-slate-500 font-mono overflow-hidden whitespace-nowrap text-ellipsis opacity-80">
                                           ...{result.fragment.substring(0, 100)}...
                                       </div>
                                   )}
                                </div>
                            ))
                         ) : (
                             <button 
                                onClick={executeContentSearch}
                                className="w-full text-left px-3 py-3 hover:bg-indigo-500/10 transition-colors flex items-center gap-2 text-indigo-300"
                             >
                                 <Search className="w-3.5 h-3.5" />
                                 <span className="text-xs font-mono">Deep search for "{searchQuery}"</span>
                             </button>
                         )}
                         
                         {localSearchResults.length === 0 && contentSearchResults.length === 0 && !isSearchingContent && (
                             <div className="p-3 text-center text-[10px] text-slate-600 font-mono">
                                 No nodes match. Try deep search.
                             </div>
                         )}
                     </div>
                 )}
            </div>
            
            {/* Filter Toggle */}
            <div className="flex items-center gap-2">
                <div className="relative">
                    <button 
                        onClick={toggleFilterMenu}
                        className={`p-1.5 rounded-lg border transition-all flex items-center gap-2 ${isFilterOpen || appliedExtensions.length > 0 || appliedDirectories.length > 0 ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' : 'bg-white/5 text-slate-400 border-white/5 hover:text-white'}`}
                        title="Filter Nodes"
                    >
                        <Filter className="w-4 h-4" />
                        {(appliedExtensions.length > 0 || appliedDirectories.length > 0) && (
                            <span className="bg-indigo-500 text-white text-[9px] px-1 rounded-full">{appliedExtensions.length + appliedDirectories.length}</span>
                        )}
                    </button>
                    
                    {isFilterOpen && (
                        <div className="absolute right-0 top-full mt-2 w-72 bg-slate-950 border border-white/10 rounded-xl shadow-2xl overflow-hidden z-30 flex flex-col animate-in fade-in zoom-in-95 duration-100">
                            <div className="flex border-b border-white/5">
                                <button 
                                    onClick={() => setFilterTab('types')}
                                    className={`flex-1 py-2 text-[10px] font-mono uppercase tracking-wider transition-colors ${filterTab === 'types' ? 'bg-indigo-500/10 text-indigo-300 border-b-2 border-indigo-500' : 'text-slate-500 hover:text-slate-300'}`}
                                >
                                    File Types
                                </button>
                                <button 
                                    onClick={() => setFilterTab('dirs')}
                                    className={`flex-1 py-2 text-[10px] font-mono uppercase tracking-wider transition-colors ${filterTab === 'dirs' ? 'bg-indigo-500/10 text-indigo-300 border-b-2 border-indigo-500' : 'text-slate-500 hover:text-slate-300'}`}
                                >
                                    Directories
                                </button>
                            </div>
                            
                            <div className="max-h-60 overflow-y-auto p-2 space-y-1">
                                {filterTab === 'types' && stats.allExts.map(ext => {
                                    const isSelected = tempExtensions.includes(ext);
                                    const count = stats.extCounts[ext] || 0;
                                    
                                    return (
                                    <button
                                        key={ext}
                                        onClick={() => toggleTempFilter(ext, 'ext')}
                                        className={`w-full flex items-center px-2 py-1.5 rounded-lg text-xs font-mono transition-colors hover:bg-white/5 ${isSelected ? 'text-indigo-300' : 'text-slate-400'}`}
                                    >
                                        <div className={`w-3.5 h-3.5 border rounded mr-2 flex items-center justify-center transition-colors ${isSelected ? 'bg-indigo-500 border-indigo-500' : 'border-slate-600'}`}>
                                            {isSelected && <Check className="w-2.5 h-2.5 text-white" />}
                                        </div>
                                        <FileType className="w-3 h-3 shrink-0 mr-2 opacity-70" />
                                        <span className="truncate flex-1 text-left">{ext}</span>
                                        <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-mono ${count > 0 ? 'bg-white/10 text-slate-400' : 'text-slate-700'}`}>
                                            {count}
                                        </span>
                                    </button>
                                )})}
                                {filterTab === 'types' && stats.allExts.length === 0 && <p className="text-xs text-slate-600 px-2 py-4 text-center">No types found</p>}

                                {filterTab === 'dirs' && stats.allDirs.map(dir => {
                                    const isSelected = tempDirectories.includes(dir);
                                    const count = stats.dirCounts[dir] || 0;

                                    return (
                                    <button
                                        key={dir}
                                        onClick={() => toggleTempFilter(dir, 'dir')}
                                        className={`w-full flex items-center px-2 py-1.5 rounded-lg text-xs font-mono transition-colors hover:bg-white/5 ${isSelected ? 'text-indigo-300' : 'text-slate-400'}`}
                                    >
                                        <div className={`w-3.5 h-3.5 border rounded mr-2 flex items-center justify-center transition-colors ${isSelected ? 'bg-indigo-500 border-indigo-500' : 'border-slate-600'}`}>
                                            {isSelected && <Check className="w-2.5 h-2.5 text-white" />}
                                        </div>
                                        <Folder className="w-3 h-3 shrink-0 mr-2 opacity-70" />
                                        <span className="truncate flex-1 text-left">{dir}</span>
                                        <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-mono ${count > 0 ? 'bg-white/10 text-slate-400' : 'text-slate-700'}`}>
                                            {count}
                                        </span>
                                    </button>
                                )})}
                                {filterTab === 'dirs' && stats.allDirs.length === 0 && <p className="text-xs text-slate-600 px-2 py-4 text-center">No directories found</p>}
                            </div>

                            <div className="p-3 border-t border-white/5 bg-slate-900/50 space-y-2">
                                <button 
                                    onClick={applyFilters} 
                                    className="w-full py-2 bg-indigo-500 hover:bg-indigo-400 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-500/20"
                                >
                                    <Play className="w-3 h-3 fill-current" /> Apply Filters
                                </button>
                                <button onClick={clearTempFilters} className="w-full py-1.5 text-[10px] text-slate-500 hover:text-white uppercase tracking-wider font-mono hover:bg-white/5 rounded transition-colors">
                                    Clear Selection
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
         </div>
         <div className="flex-1 relative w-full h-full">
             <D3FlowChart 
                data={processedGraphData} 
                onNodeClick={handleNodeClick} 
                highlightedNodeIds={highlightedNodeIds} 
             />
         </div>
      </div>

      {/* Right Pane: Contextual Dev Terminal & Task List */}
      <div className="w-full lg:w-[450px] h-[500px] lg:h-auto glass-panel rounded-3xl flex flex-col overflow-hidden shrink-0 mb-6 lg:mb-0 transition-colors">
         
         {/* Tab Header */}
         <div className="px-2 py-2 bg-slate-950/50 border-b border-white/5 flex items-center gap-1 shrink-0 overflow-x-auto justify-between">
              <div className="flex items-center gap-1 flex-1">
                  <button 
                    onClick={() => setActiveTab('chat')}
                    className={`flex-1 min-w-[80px] flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-mono uppercase tracking-wider transition-all ${
                        activeTab === 'chat' 
                        ? 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20' 
                        : 'text-slate-500 hover:text-slate-300 hover:bg-white/5 border border-transparent'
                    }`}
                  >
                      <Terminal className="w-3.5 h-3.5" /> Assistant
                  </button>
                  <button 
                    onClick={() => setActiveTab('code')}
                    disabled={!selectedNode}
                    className={`flex-1 min-w-[80px] flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-mono uppercase tracking-wider transition-all ${
                        activeTab === 'code' 
                        ? 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20' 
                        : 'text-slate-500 hover:text-slate-300 hover:bg-white/5 border border-transparent disabled:opacity-50'
                    }`}
                  >
                      <FileCode className="w-3.5 h-3.5" /> Source
                  </button>
                  <button 
                    onClick={() => setActiveTab('tasks')}
                    className={`flex-1 min-w-[80px] flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-mono uppercase tracking-wider transition-all ${
                        activeTab === 'tasks' 
                        ? 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20' 
                        : 'text-slate-500 hover:text-slate-300 hover:bg-white/5 border border-transparent'
                    }`}
                  >
                      <ListTodo className="w-3.5 h-3.5" /> Tasks
                  </button>
              </div>

              {/* Theme Toggle */}
              <div className="flex items-center gap-1 border-l border-white/5 pl-2 ml-1">
                   <button onClick={() => handleThemeChange('dark')} className={`p-1.5 rounded-lg transition-colors ${theme === 'dark' ? 'text-indigo-400 bg-indigo-500/10' : 'text-slate-500 hover:text-slate-300'}`} title="Dark Mode">
                       <Moon className="w-3.5 h-3.5" />
                   </button>
                   <button onClick={() => handleThemeChange('light')} className={`p-1.5 rounded-lg transition-colors ${theme === 'light' ? 'text-amber-500 bg-amber-500/10' : 'text-slate-500 hover:text-slate-300'}`} title="Light Mode">
                       <Sun className="w-3.5 h-3.5" />
                   </button>
                   <button onClick={() => handleThemeChange('solarized')} className={`p-1.5 rounded-lg transition-colors ${theme === 'solarized' ? 'text-teal-400 bg-teal-500/10' : 'text-slate-500 hover:text-slate-300'}`} title="Solarized">
                       <Sunset className="w-3.5 h-3.5" />
                   </button>
              </div>
         </div>

         {/* Content Area */}
         {activeTab === 'chat' && (
             <>
                {/* Persona Selector Dropdown */}
                <div className="px-4 py-3 bg-slate-900/30 border-b border-white/5 flex items-center justify-between shrink-0 relative z-30">
                    <div className="flex items-center gap-2 w-full">
                        <span className="text-[10px] text-slate-500 font-mono uppercase tracking-wider shrink-0">Persona:</span>
                        
                        <div className="relative w-full group/trigger">
                            <button 
                                onClick={() => setIsPersonaMenuOpen(!isPersonaMenuOpen)}
                                className="w-full flex items-center justify-between px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all text-xs font-mono text-slate-200 group"
                            >
                                <div className="flex items-center gap-2">
                                    <activePersona.icon className="w-3.5 h-3.5 text-indigo-400" />
                                    <span>{activePersona.label}</span>
                                </div>
                                <ChevronDown className={`w-3.5 h-3.5 text-slate-500 transition-transform ${isPersonaMenuOpen ? 'rotate-180' : ''}`} />
                            </button>

                            {/* Custom Tooltip on Hover for Active Persona (only if menu closed) */}
                            {!isPersonaMenuOpen && (
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max max-w-[240px] px-3 py-2 bg-slate-900/95 backdrop-blur-md text-slate-300 text-[10px] rounded-lg border border-white/10 opacity-0 group-hover/trigger:opacity-100 transition-all duration-200 pointer-events-none z-40 shadow-xl font-mono text-center transform translate-y-2 group-hover/trigger:translate-y-0">
                                    <p className="font-bold text-indigo-300 mb-1">{activePersona.label}</p>
                                    {activePersona.desc}
                                    <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-slate-900/95"></div>
                                </div>
                            )}

                            {isPersonaMenuOpen && (
                                <>
                                    <div className="fixed inset-0 z-10" onClick={() => setIsPersonaMenuOpen(false)}></div>
                                    <div className="absolute top-full left-0 mt-2 w-full bg-slate-900 border border-white/10 rounded-xl shadow-xl z-20 flex flex-col animate-in fade-in zoom-in-95 duration-100">
                                        {PERSONAS.map((p, idx) => (
                                            <button
                                                key={p.id}
                                                onClick={() => { setActivePersona(p); setIsPersonaMenuOpen(false); }}
                                                className={`w-full text-left px-3 py-3 transition-colors flex items-center gap-3 group relative hover:bg-white/5 
                                                    ${activePersona.id === p.id ? 'bg-indigo-500/10' : ''}
                                                    ${idx === 0 ? 'rounded-t-xl' : ''} 
                                                    ${idx === PERSONAS.length - 1 ? 'rounded-b-xl' : ''}
                                                `}
                                            >
                                                <div className={`p-1.5 rounded-lg shrink-0 ${activePersona.id === p.id ? 'bg-indigo-500/20 text-indigo-300' : 'bg-white/5 text-slate-400 group-hover:text-slate-200'}`}>
                                                    <p.icon className="w-3.5 h-3.5" />
                                                </div>
                                                <div className="min-w-0 flex-1">
                                                    <div className="flex items-center justify-between">
                                                        <span className={`text-xs font-bold font-mono ${activePersona.id === p.id ? 'text-indigo-300' : 'text-slate-300'}`}>{p.label}</span>
                                                        {activePersona.id === p.id && <Check className="w-3 h-3 text-indigo-400" />}
                                                    </div>
                                                    
                                                    {/* Mobile: Inline Desc */}
                                                    <p className="text-[10px] text-slate-500 leading-tight mt-0.5 lg:hidden">
                                                        {p.desc}
                                                    </p>
                                                </div>

                                                {/* Desktop: Flyout Tooltip (Left side) */}
                                                <div className="hidden lg:block absolute right-full top-1/2 -translate-y-1/2 mr-3 w-48 px-3 py-2 bg-slate-900/95 backdrop-blur-xl border border-white/10 text-slate-300 text-[10px] rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-200 transform translate-x-2 group-hover:translate-x-0 shadow-2xl z-50 invisible group-hover:visible">
                                                    <div className="absolute right-[-5px] top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-slate-900 border-r border-t border-white/10 rotate-45"></div>
                                                    <p className="font-bold text-indigo-400 mb-1 font-mono">{p.label}</p>
                                                    <p className="leading-relaxed font-sans opacity-90">{p.desc}</p>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                </div>

                {/* Selected Node Context Header & Quick Actions */}
                <div className="bg-slate-950/80 border-b border-white/5 p-4 shrink-0 space-y-3 animate-in fade-in">
                    {selectedNode ? (
                        <>
                            <div className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-3 overflow-hidden">
                                    <div className="p-2 bg-indigo-500/20 rounded-lg border border-indigo-500/30 shrink-0">
                                        {selectedNode.type === 'cluster' ? (
                                            <Layers className="w-5 h-5 text-indigo-300" />
                                        ) : (
                                            <Code2 className="w-5 h-5 text-indigo-300" />
                                        )}
                                    </div>
                                    <div className="overflow-hidden">
                                        <p className="text-[10px] text-indigo-400 font-mono uppercase tracking-wider">
                                            {selectedNode.type === 'cluster' ? 'Cluster Group' : 'Active Node'}
                                        </p>
                                        <p className="text-sm text-slate-200 font-mono truncate font-medium" title={selectedNode.label}>{selectedNode.label}</p>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => selectedNode.type !== 'cluster' && setShowFileModal(true)}
                                    disabled={selectedNode.type === 'cluster'}
                                    className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors border border-white/5 disabled:opacity-50 disabled:cursor-not-allowed"
                                    title="Open File Details Modal"
                                >
                                    <Info className="w-4 h-4" />
                                </button>
                            </div>
                            {/* Quick Actions */}
                            <div className="grid grid-cols-3 gap-2 pt-1">
                                {QUICK_ACTIONS.map((action, idx) => (
                                    <button
                                        key={idx}
                                        onClick={() => handleQuickAction(action.prompt)}
                                        disabled={chatLoading}
                                        className="flex flex-col items-center justify-center gap-1 p-2 rounded-lg bg-white/5 hover:bg-indigo-500/20 border border-white/5 hover:border-indigo-500/30 transition-all group disabled:opacity-50"
                                    >
                                        <action.icon className="w-4 h-4 text-slate-400 group-hover:text-indigo-300" />
                                        <span className="text-[10px] font-mono text-slate-500 group-hover:text-indigo-200 uppercase">{action.label}</span>
                                    </button>
                                ))}
                            </div>
                        </>
                    ) : (
                        <div className="flex items-center gap-3 opacity-70">
                            <div className="p-2 bg-slate-800 rounded-lg border border-white/5">
                                <Cpu className="w-5 h-5 text-slate-500" />
                            </div>
                            <div>
                                <p className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">Global Scope</p>
                                <p className="text-sm text-slate-400 font-mono">No node selected</p>
                            </div>
                        </div>
                    )}
                </div>
                
                {/* Chat History */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-sm bg-slate-950/30 relative min-h-0">
                    {chatHistory.length === 0 && !chatLoading && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-600 space-y-4 p-8 text-center opacity-60 pointer-events-none">
                            <div className="relative">
                                <Bot className="w-12 h-12 text-indigo-500/50" />
                                <Sparkles className="w-5 h-5 text-emerald-400/50 absolute -top-1 -right-1 animate-pulse" />
                            </div>
                            <p className="text-sm max-w-[250px] leading-relaxed">
                                Select a node to unlock context-aware AI debugging.
                                <br/>
                                <span className="text-indigo-400 opacity-80 mt-2 block text-xs">Active Persona: {activePersona.label}</span>
                            </p>
                        </div>
                    )}
                    {chatHistory.map((msg, idx) => (
                        <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
                            <div className={`max-w-[90%] p-3 rounded-xl ${
                            msg.role === 'user' 
                                ? 'bg-indigo-600/20 text-indigo-100 border border-indigo-500/30 rounded-br-sm shadow-sm' 
                                : 'bg-slate-800/80 text-slate-200 border border-white/10 rounded-bl-sm shadow-sm'
                            }`}>
                                <div className="whitespace-pre-wrap leading-relaxed text-[13px]">{msg.text}</div>
                            </div>
                        </div>
                        ))
                    }
                    {chatLoading && (
                        <div className="flex justify-start animate-in fade-in">
                            <div className="bg-slate-800/80 p-3 rounded-xl rounded-bl-sm border border-white/10 flex items-center gap-1.5">
                            <div className="flex gap-1">
                                <div className="w-1.5 h-1.5 bg-indigo-400/70 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                <div className="w-1.5 h-1.5 bg-indigo-400/70 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                <div className="w-1.5 h-1.5 bg-indigo-400/70 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                            </div>
                            </div>
                        </div>
                    )}
                    <div ref={chatEndRef} />
                </div>

                {/* Input Area */}
                <div className="p-3 bg-slate-950/80 border-t border-white/5 shrink-0">
                    <form onSubmit={handleAskQuestion} className="relative flex items-center glass-panel rounded-xl p-1.5 focus-within:ring-1 ring-indigo-500/50 transition-all bg-slate-900/20">
                        <span className="pl-2 pr-2 text-indigo-500 font-mono flex-shrink-0">{'>'}</span>
                        <input
                        type="text"
                        value={questionInput}
                        onChange={(e) => setQuestionInput(e.target.value)}
                        placeholder={`Ask ${activePersona.id}...`}
                        disabled={chatLoading}
                        className="w-full bg-transparent border-none text-slate-200 placeholder:text-slate-600 focus:ring-0 py-1.5 px-0 font-mono text-sm"
                        />
                        <button type="submit" disabled={!questionInput.trim() || chatLoading} className="p-1.5 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded-lg transition-colors disabled:opacity-0 flex-shrink-0">
                            <MessageSquare className="w-4 h-4" />
                        </button>
                    </form>
                </div>
             </>
         )}

         {activeTab === 'code' && (
             <div className="flex-1 overflow-hidden flex flex-col animate-in fade-in slide-in-from-right-4 bg-slate-950">
                 <div className="px-4 py-2 border-b border-white/5 bg-slate-900/50 flex items-center justify-between">
                     <span className="text-xs font-mono text-slate-400">{selectedNode?.label || 'No file selected'}</span>
                     <div className="flex gap-1.5">
                         <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                         <div className="w-2.5 h-2.5 rounded-full bg-slate-700"></div>
                     </div>
                 </div>
                 <div className="flex-1 overflow-auto p-4 relative">
                     {loadingContent ? (
                         <div className="absolute inset-0 flex items-center justify-center">
                             <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                         </div>
                     ) : fileContent ? (
                         <pre className="font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                             {fileContent}
                         </pre>
                     ) : (
                         <div className="flex flex-col items-center justify-center h-full text-slate-600 space-y-2 opacity-60">
                            <FileCode className="w-8 h-8" />
                            <p className="text-xs font-mono">Select a file node to view source.</p>
                         </div>
                     )}
                 </div>
             </div>
         )}

         {activeTab === 'tasks' && (
             <div className="flex-1 overflow-hidden flex flex-col animate-in fade-in slide-in-from-right-4">
                 <TaskList />
             </div>
         )}
      </div>
    </div>
  );
};

export default DevStudio;

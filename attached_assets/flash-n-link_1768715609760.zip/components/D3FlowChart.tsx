
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { DataFlowGraph, D3Node, D3Link } from '../types';
import { ZoomIn, ZoomOut, Maximize } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface D3FlowChartProps {
  /** The graph data containing nodes and links */
  data: DataFlowGraph;
  /** Callback fired when a node is clicked */
  onNodeClick?: (node: D3Node) => void;
  /** Array of node IDs to highlight visually */
  highlightedNodeIds?: string[]; 
}

// Colors adapted for Dark/Light modes
const COLORS_DARK = [
  "#4cc9f0", "#f72585", "#7209b7", "#3a0ca3", "#4361ee", 
  "#4d908e", "#57cc99", "#f3722c", "#f8961e", "#f9c74f"
];

// Slightly darker/more saturated for visibility on white
const COLORS_LIGHT = [
  "#0096c7", "#d00000", "#560bad", "#3f37c9", "#4361ee", 
  "#2a9d8f", "#264653", "#e76f51", "#f4a261", "#e9c46a"
];

/**
 * D3FlowChart Component
 * 
 * Renders an interactive force-directed graph.
 * Handles:
 * - Dynamic clustering visualization (larger nodes for clusters).
 * - Zoom and Pan behaviors.
 * - Node dragging.
 * - Visual highlighting of search results.
 */
const D3FlowChart: React.FC<D3FlowChartProps> = ({ data, onNodeClick, highlightedNodeIds = [] }) => {
  const { theme } = useTheme();
  const svgRef = useRef<SVGSVGElement>(null);
  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const [sim, setSim] = useState<d3.Simulation<D3Node, D3Link> | null>(null);

  // Determine palette based on theme
  const palette = theme === 'light' ? COLORS_LIGHT : COLORS_DARK;
  const strokeColor = theme === 'light' ? "#cbd5e1" : "#1e293b"; // slate-300 vs slate-800
  const clusterBg = theme === 'light' ? "#f1f5f9" : "#0f172a"; // slate-100 vs slate-900
  const linkColor = theme === 'light' ? "#94a3b8" : "#94a3b8";
  const textColor = theme === 'light' ? "#334155" : "#e2e8f0";

  // Initialize and update the D3 simulation
  useEffect(() => {
    if (!data || !svgRef.current) return;

    // Dynamically get dimensions from container or SVG
    const width = svgRef.current.clientWidth || 800;
    // Use clientHeight if available to respect responsive containers, default to 600 if 0
    const height = svgRef.current.clientHeight || 600;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove(); // Clear previous rendering

    const g = svg.append("g"); // Create container group for zoom

    // Initialize Force Simulation
    // Adjust forces based on node type to separate clusters from files
    const simulation = d3.forceSimulation<D3Node, D3Link>(data.nodes)
      .force("link", d3.forceLink<D3Node, D3Link>(data.links)
        .id(d => d.id)
        .distance(d => {
            // Links connected to clusters should be longer to give space
            const source = (d.source as any);
            const target = (d.target as any);
            if (source.type === 'cluster' || target.type === 'cluster') return 150;
            return 80;
        })
      )
      .force("charge", d3.forceManyBody().strength(d => (d as D3Node).type === 'cluster' ? -800 : -200))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collide", d3.forceCollide().radius(d => (d as D3Node).type === 'cluster' ? 50 : 15).iterations(2))
      .force("x", d3.forceX().strength(0.08))
      .force("y", d3.forceY().strength(0.08));
    
    setSim(simulation);

    // Draw Links
    const link = g.append("g")
      .attr("stroke", linkColor) 
      .attr("stroke-opacity", 0.3)
      .selectAll("line")
      .data(data.links)
      .join("line")
      .attr("stroke-width", (d: any) => Math.sqrt(d.value || 1) * 1.5);

    // Draw Nodes Group
    const nodeGroup = g.append("g")
      .selectAll("g")
      .data(data.nodes)
      .join("g")
      .style("cursor", "pointer")
      .attr("id", (d: any) => `node-${d.id.replace(/[^a-zA-Z0-9]/g, '-')}`)
      .on("click", (event, d: any) => {
        if (onNodeClick) {
            event.stopPropagation();
            onNodeClick(d);
        }
      });

    // Draw Node Circles
    nodeGroup.append("circle")
      .attr("r", (d: any) => {
          // Cluster nodes are larger based on file count
          if (d.type === 'cluster') return 22 + Math.min((d.fileCount || 0), 10);
          return d.id === 'root' ? 14 : 8;
      })
      .attr("fill", (d: any) => {
          if (d.type === 'cluster') return clusterBg; 
          return palette[d.group % palette.length];
      })
      .attr("stroke", (d: any) => {
          if (d.type === 'cluster') return palette[d.group % palette.length];
          return strokeColor;
      })
      .attr("stroke-width", (d: any) => d.type === 'cluster' ? 3 : 2)
      .attr("stroke-dasharray", (d: any) => d.type === 'cluster' ? "4 2" : "0")
      .attr("class", "node-circle transition-all duration-300 ease-in-out hover:stroke-current");

    // Add File Count Text for Clusters
    nodeGroup.filter((d: any) => d.type === 'cluster')
        .append("text")
        .attr("text-anchor", "middle")
        .attr("dy", 5)
        .attr("fill", (d: any) => palette[d.group % palette.length])
        .attr("font-size", "14px")
        .attr("font-weight", "bold")
        .style("pointer-events", "none")
        .text((d: any) => d.fileCount);

    // Add Node Label Text
    nodeGroup.append("text")
      .text((d: any) => d.label)
      .attr("x", (d: any) => d.type === 'cluster' ? 30 : 16)
      .attr("y", 5)
      .attr("fill", textColor)
      .attr("font-size", (d: any) => d.type === 'cluster' ? "14px" : "12px")
      .attr("font-family", "JetBrains Mono, monospace")
      .attr("font-weight", (d: any) => d.type === 'cluster' ? "700" : "500")
      .style("text-shadow", theme === 'light' ? "none" : "0 2px 4px rgba(0,0,0,0.9)")
      .style("pointer-events", "none");

    // Define Drag Behavior
    const drag = d3.drag<SVGGElement, D3Node>()
      .on("start", (event, d) => {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
      })
      .on("drag", (event, d) => {
        d.fx = event.x;
        d.fy = event.y;
      })
      .on("end", (event, d) => {
        if (!event.active) simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
      });

    nodeGroup.call(drag as any); 

    // Define Zoom Behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on("zoom", (event) => {
        g.attr("transform", event.transform);
      });

    svg.call(zoom);
    zoomRef.current = zoom;

    // Simulation Tick Updates
    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => (d.source as D3Node).x!)
        .attr("y1", (d: any) => (d.source as D3Node).y!)
        .attr("x2", (d: any) => (d.target as D3Node).x!)
        .attr("y2", (d: any) => (d.target as D3Node).y!);

      nodeGroup
        .attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });

    return () => {
      simulation.stop();
    };
  }, [data, theme]); // Re-run when data structure or THEME changes

  // Effect to handle highlighting logic (Search/Selection)
  useEffect(() => {
    if (!svgRef.current || !data.nodes) return;
    
    const svg = d3.select(svgRef.current);
    const circles = svg.selectAll<SVGCircleElement, D3Node>("circle");
    const texts = svg.selectAll<SVGTextElement, D3Node>("text");
    const lines = svg.selectAll<SVGLineElement, D3Link>("line");

    if (highlightedNodeIds && highlightedNodeIds.length > 0) {
        // Dim everything first
        circles.transition().duration(300).style("opacity", 0.1);
        texts.transition().duration(300).style("opacity", 0.1);
        lines.transition().duration(300).style("opacity", 0.05);
        
        // Filter for nodes that are highlighted
        const selectedCircles = circles.filter((d) => highlightedNodeIds.includes(d.id));
        const selectedTexts = texts.filter((d) => highlightedNodeIds.includes(d.id));

        // Highlight selected nodes
        selectedCircles
            .transition().duration(300)
            .style("opacity", 1)
            .attr("stroke", theme === 'light' ? "#000" : "#fff")
            .attr("stroke-width", (d) => d.type === 'cluster' ? 4 : 3)
            .style("filter", theme === 'light' ? "drop-shadow(0 0 5px rgba(0,0,0,0.3))" : "drop-shadow(0 0 10px rgba(255,255,255,0.7))");

        selectedTexts
            .transition().duration(300)
            .style("opacity", 1)
            .style("font-weight", "bold");

        // Center view on the first highlighted node if only one is selected
        if (highlightedNodeIds.length === 1) {
            const node = data.nodes.find(n => n.id === highlightedNodeIds[0]);
            if (node && node.x !== undefined && node.y !== undefined && zoomRef.current) {
                // Calculate dimensions
                const width = svgRef.current.clientWidth || 800;
                const height = svgRef.current.clientHeight || 600;
                
                const transform = d3.zoomIdentity
                    .translate(width / 2, height / 2)
                    .scale(1.5)
                    .translate(-node.x, -node.y);

                svg.transition().duration(750).call(zoomRef.current.transform as any, transform);
            }
        }
    } else {
        // Reset to default state
        circles.transition().duration(300)
          .style("opacity", 1)
          .attr("stroke", (d: any) => {
             if (d.type === 'cluster') return palette[d.group % palette.length];
             return strokeColor;
          })
          .attr("stroke-width", (d: any) => d.type === 'cluster' ? 3 : 2)
          .style("filter", "none");
          
        texts.transition().duration(300)
          .style("opacity", 1)
          .style("font-weight", (d: any) => d.type === 'cluster' ? "700" : "500");
          
        lines.transition().duration(300).style("opacity", 1);
    }
  }, [highlightedNodeIds, data.nodes, theme]);

  return (
    <div className="w-full h-full relative overflow-hidden bg-slate-950/20 rounded-2xl">
      <svg ref={svgRef} className="w-full h-full" />
      
      {/* Zoom Controls */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2">
        <button 
           onClick={() => {
              if (svgRef.current && zoomRef.current) {
                 d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy as any, 1.2);
              }
           }}
           className="p-2 bg-slate-900/80 border border-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
        >
            <ZoomIn className="w-5 h-5" />
        </button>
        <button 
           onClick={() => {
              if (svgRef.current && zoomRef.current) {
                 d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy as any, 0.8);
              }
           }}
           className="p-2 bg-slate-900/80 border border-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
        >
            <ZoomOut className="w-5 h-5" />
        </button>
        <button 
           onClick={() => {
              if (svgRef.current && zoomRef.current) {
                  // Reset zoom
                  const width = svgRef.current.clientWidth || 800;
                  const height = svgRef.current.clientHeight || 600;
                  const transform = d3.zoomIdentity.translate(width/2, height/2).scale(1).translate(-width/2, -height/2); // approximate center logic or just identity
                  d3.select(svgRef.current).transition().duration(500).call(zoomRef.current.transform as any, d3.zoomIdentity);
              }
           }}
           className="p-2 bg-slate-900/80 border border-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
        >
            <Maximize className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default D3FlowChart;
